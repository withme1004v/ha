import React from 'react';

function TodoReadPage() {
    return (
        <div>

            <div className={'text-4xl'}>Todo Read Page</div>

        </div>
    );
}

export default TodoReadPage;