import React from 'react';

function TodoAddPage() {
    return (
        <div>
            <div className={'text-4xl'}>Todo Add Page</div>
        </div>
    );
}

export default TodoAddPage;