package com.project.fastpickup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FastpickupApplication {

    public static void main(String[] args) {
        SpringApplication.run(FastpickupApplication.class, args);
    }

}
