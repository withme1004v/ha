package org.zerock.bj2.mappers;


public interface TimeMapper {
  
  //@Select("select now()")
  String getTime();

}
