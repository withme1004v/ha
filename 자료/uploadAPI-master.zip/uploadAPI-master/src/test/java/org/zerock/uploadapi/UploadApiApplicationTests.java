package org.zerock.uploadapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
