package org.zerock.serverex2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerEx2Application {

    public static void main(String[] args) {
        SpringApplication.run(ServerEx2Application.class, args);
    }

}
