import { redirect } from "next/navigation";


export default function TodoIndexPage () {

    redirect("/todo/list")

}