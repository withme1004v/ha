

export default  function AboutPage () {

    return (
        <div>
            <div className="text-4xl ">
            About Page
            </div>
        </div>
    )

}