package org.zerock.serverex1rds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerEx1RdsApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerEx1RdsApplication.class, args);
    }

}
