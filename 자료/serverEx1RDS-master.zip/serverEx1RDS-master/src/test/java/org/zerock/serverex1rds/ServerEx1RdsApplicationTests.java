package org.zerock.serverex1rds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerEx1RdsApplicationTests {

    @Test
    void contextLoads() {
    }

}
