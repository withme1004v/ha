
function HelloComponent() {
    return (
        <div>
            <h1>Hello Component</h1>
            <h1>Hello Component</h1>
            <h1>Hello Component</h1>
        </div>
    );
}

export default HelloComponent;