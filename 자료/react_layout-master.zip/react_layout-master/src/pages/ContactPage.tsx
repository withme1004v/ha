
function ContactPage() {
    return (
        <div>
            <div>About Page</div>
        </div>
    );
}

export default ContactPage;