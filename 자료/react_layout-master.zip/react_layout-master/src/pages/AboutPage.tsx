
function AboutPage() {
    return (
        <div>
            <div>About Page</div>
        </div>
    );
}

export default AboutPage;