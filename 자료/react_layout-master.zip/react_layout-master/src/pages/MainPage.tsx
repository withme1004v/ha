
function MainPage() {
    return (
        <div>
            <div>Main Page</div>
        </div>
    );
}

export default MainPage;