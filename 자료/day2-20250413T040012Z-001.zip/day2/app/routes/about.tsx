


function AboutPage() {

    return (
        <div>
            <div className={'text-4xl'}>About Pge</div>
        </div>
    )
}
export default AboutPage