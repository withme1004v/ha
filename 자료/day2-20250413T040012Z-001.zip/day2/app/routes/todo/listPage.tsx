import React, {useState} from 'react';
import ListComponent from "~/components/todo/listComponent";
import ListComponent2 from "~/components/todo2/listComponent";

function ListPage() {



    return (
        <div>
            <div className={'text-4xl'}>List Page</div>

            <ListComponent2 ></ListComponent2>
        </div>
    );
}

export default ListPage;