import {NavLink, useNavigate} from "react-router";


interface PagingComponentProps {
    prev: boolean,
    next: boolean,
    prevPage: number,
    nextPage: number,
    totalPage: number,
    totalCount: number,
    pageNumList: number[],
    current: number
    change: () => void,
}


function PagingComponent( {pageNumList, prev, next, prevPage, nextPage, current, change}:PagingComponentProps) {

  const navigate = useNavigate();

  const handlePageChange = (page: number) => {

      navigate('../list?page=' + page);
      change();
  }

  return ( 
    <div className="justify-items-center">
      <ul className="flex">

        {prev &&
            <li key={prevPage} className="p-1 m-1 bg-blue-400 text-white" onClick={()=> handlePageChange(prevPage)}>
              Prev
            </li>
        }


        {pageNumList.map( (page, idx) =>

            <li className={`p-1 m-1 w-10 text-center bg-blue-400 ${current != page ? "text-white" : "text-black"}`}
                onClick={()=> handlePageChange(page)}>
              {page}
            </li>
        )}

        {next &&
            <li key={nextPage} className="p-1 m-1 bg-blue-400 text-white"
                onClick={()=> handlePageChange(nextPage)}>
              Next
            </li>
        }
      </ul>
    </div>
  )

}

export default PagingComponent;