package org.zerock.serverex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerEx1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
